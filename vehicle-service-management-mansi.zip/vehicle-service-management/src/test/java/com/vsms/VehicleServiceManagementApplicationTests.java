package com.vsms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleServiceManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
